import azapi

# apps = azapi.call_graph(resource='applications', filter="startswith(displayName,'s')")

vnet_result = azapi.call_rest(
    verb = 'GET',
    scope=f'/subscriptions/cdc5dd34-1f58-4f80-b045-8cd71ff51321/resourceGroups/rg-testnets', 
    resource = f'Microsoft.Network/virtualNetworks/vnet-removnet', 
    api_version='2022-07-01'
)



getuser = azapi.call_graph(resource='users/014d76d6-1f7f-4ea9-bda1-1859ef84443e')

subs = azapi.call_rest(resource='subscriptions', api_version = '2022-09-01')

# vnets = azapi.call_rest(
#   resource='Microsoft.Network/virtualNetworks', 
#   scope='subscriptions/527be2d5-0031-4243-b09a-f8326ee171f2',
#   api_version='2022-05-01')

rest_paging_test = azapi.call_rest(
    resource = 'Microsoft.Authorization/policyDefinitions ',
    scope='subscriptions/527be2d5-0031-4243-b09a-f8326ee171f2',
    api_version = '2021-06-01'
    )

print(":")