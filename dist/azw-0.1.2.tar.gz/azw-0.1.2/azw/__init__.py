from .azapi import call_rest
from .azapi import call_graph
from .azapi import jprint
from .azapi import jdump
from .azapi import jwrite
